#!/usr/bin/env python3

from sys import stdin

for line in stdin.readlines():
    print(' '.join(line.strip()))
